"""Tests for Week 1, Day 1 — solution.py and type hint examples.

Run with:
    pytest tests/test.py -v
"""

import pytest

from docstrings.solution import calculate_tax_inclusive_price
from type_hints.structured_type import PipelineConfig, process_user


# ---------------------------------------------------------
# Tests for calculate_tax_inclusive_price
# ---------------------------------------------------------

class TestCalculateTaxInclusivePrice:

    def test_single_record_default_tax(self):
        records = [{"price": 100.0}]
        result = calculate_tax_inclusive_price(records)
        assert result == [118.0]

    def test_multiple_records(self):
        records = [{"price": 100.0}, {"price": 250.50}]
        result = calculate_tax_inclusive_price(records)
        assert result == [118.0, 295.59]

    def test_custom_tax_rate(self):
        records = [{"price": 200.0}]
        result = calculate_tax_inclusive_price(records, tax_rate=0.05)
        assert result == [210.0]

    def test_missing_price_key_defaults_to_zero(self):
        records = [{"item": "No price here"}]
        result = calculate_tax_inclusive_price(records)
        assert result == [0.0]

    def test_empty_list_returns_empty(self):
        assert calculate_tax_inclusive_price([]) == []

    def test_zero_tax_rate(self):
        records = [{"price": 500.0}]
        result = calculate_tax_inclusive_price(records, tax_rate=0.0)
        assert result == [500.0]

    def test_result_rounded_to_two_decimals(self):
        records = [{"price": 99.99}]
        result = calculate_tax_inclusive_price(records)
        assert result == [117.99]


# ---------------------------------------------------------
# Tests for PipelineConfig dataclass
# ---------------------------------------------------------

class TestPipelineConfig:

    def test_default_values(self):
        cfg = PipelineConfig(name="ingest-v1")
        assert cfg.batch_size == 64
        assert cfg.retries == 3
        assert cfg.tags == []

    def test_custom_values(self):
        cfg = PipelineConfig(name="ingest-v1", batch_size=128, retries=5)
        assert cfg.batch_size == 128
        assert cfg.retries == 5

    def test_tags_are_independent_per_instance(self):
        cfg1 = PipelineConfig(name="a")
        cfg2 = PipelineConfig(name="b")
        cfg1.tags.append("ml")
        assert cfg2.tags == []   # mutable default_factory keeps them separate


# ---------------------------------------------------------
# Tests for process_user (TypedDict)
# ---------------------------------------------------------

class TestProcessUser:

    def test_formats_name_and_email(self):
        user = {"id": 1, "name": "alice", "email": "a@x.com", "active": True}
        assert process_user(user) == "alice (a@x.com)"

    def test_different_user(self):
        user = {"id": 2, "name": "bob", "email": "b@x.com", "active": False}
        assert process_user(user) == "bob (b@x.com)"
