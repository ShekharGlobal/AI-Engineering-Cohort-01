"""Type Hints — Collections — Week 1, Day 1.

Python 3.9+: use built-in generics directly (list, dict, tuple, set).
No import from typing needed for these basic collection types.
"""

from typing import Callable


# list[T] — a list of items of type T
def load_ids() -> list[int]:
    return [1, 2, 3, 4]


# dict[K, V] — keys of type K, values of type V
def get_headers() -> dict[str, str]:
    return {"Content-Type": "application/json"}


# tuple[X, Y] — fixed-length, positional types
def get_coordinates() -> tuple[float, float]:
    return (28.6139, 77.2090)  # Delhi lat/lng


# set[T] — unique items
def unique_tags(items: list[str]) -> set[str]:
    return set(items)


# Nested: list of dicts — common for batch records
def fetch_records() -> list[dict[str, str | int]]:
    return [
        {"id": 1, "name": "alice"},
        {"id": 2, "name": "bob"},
    ]


# Callable[[ArgType, ...], ReturnType] — for passing functions as arguments
def apply_transform(
    records: list[dict],
    transform: Callable[[dict], dict],
) -> list[dict]:
    return [transform(r) for r in records]
