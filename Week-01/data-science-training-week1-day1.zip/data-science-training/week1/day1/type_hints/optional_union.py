"""Type Hints — Optional and Union — Week 1, Day 1.

Optional[X]  → value is X or None  (use when something may be absent)
Union[X, Y]  → value is X or Y     (use when multiple types are valid)
X | Y        → Python 3.10+ shorthand for Union[X, Y]
"""

import os
from typing import Optional, Union


# Optional[str] — the value can be a string OR None
def get_env(key: str, default: Optional[str] = None) -> Optional[str]:
    return os.getenv(key, default)


# Python 3.10+ shorthand: str | None  (same as Optional[str])
def find_user(user_id: int) -> str | None:
    users = {1: "alice", 2: "bob"}
    return users.get(user_id)


# Union[X, Y] — value can be str OR int (neither is None specifically)
def parse_id(raw: Union[str, int]) -> int:
    return int(raw)


# Practical: config reader that may fail and return None
def read_config(path: str) -> Optional[dict]:
    try:
        import json
        with open(path) as f:
            return json.load(f)
    except FileNotFoundError:
        return None


# --- Avoid ---
# def get_env(key, default=None):   # wrong: no annotations at all
#     return os.getenv(key, default)
