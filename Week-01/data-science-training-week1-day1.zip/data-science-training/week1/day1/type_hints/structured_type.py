"""Type Hints — Structured Types — Week 1, Day 1.

TypedDict  → annotate plain dicts that follow a fixed shape
@dataclass → cleaner alternative with auto __init__, __repr__, __eq__

Use TypedDict when you must work with plain dicts (APIs, JSON payloads).
Use @dataclass when you control the object and want methods/defaults.
"""

from dataclasses import dataclass, field
from typing import TypedDict


# TypedDict: tells mypy exactly what keys and types a dict must have
class UserRecord(TypedDict):
    id: int
    name: str
    email: str
    active: bool


def process_user(user: UserRecord) -> str:
    return f"{user['name']} ({user['email']})"


# @dataclass: generates __init__, __repr__, __eq__ automatically
@dataclass
class PipelineConfig:
    name: str
    batch_size: int = 64
    retries: int = 3
    tags: list[str] = field(default_factory=list)  # mutable default


# Usage
if __name__ == "__main__":
    # TypedDict usage
    user: UserRecord = {"id": 1, "name": "alice", "email": "a@x.com", "active": True}
    print(process_user(user))

    # dataclass usage — auto __init__, no boilerplate
    cfg = PipelineConfig(name="ingest-v1", batch_size=128)
    print(cfg)
    # PipelineConfig(name='ingest-v1', batch_size=128, retries=3, tags=[])
