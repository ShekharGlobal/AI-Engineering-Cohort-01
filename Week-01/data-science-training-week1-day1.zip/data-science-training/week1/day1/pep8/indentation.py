"""PEP-8 Indentation & Spacing Rules — Week 1, Day 1.

Covers: 4-space indent, blank lines between definitions,
line length (max 88 with black), continuation lines.
"""

import os
import logging


# Two blank lines before every top-level class or function


class ConfigManager:
    """Manages platform configuration from environment."""

    DEFAULT_ENV = "development"

    def __init__(self, prefix: str = "APP") -> None:
        self.prefix = prefix
        self._cache: dict[str, str] = {}

    def get(self, key: str) -> str | None:      # one blank line between methods
        full_key = f"{self.prefix}_{key}"
        if full_key in self._cache:
            return self._cache[full_key]
        value = os.getenv(full_key)
        if value is not None:
            self._cache[full_key] = value
        return value

    def require(self, key: str) -> str:
        value = self.get(key)
        if value is None:
            raise EnvironmentError(
                f"Required config key '{self.prefix}_{key}' is not set."
            )                                    # closing paren on its own line
        return value


def build_config(prefix: str = "APP") -> ConfigManager:   # two blank lines before
    return ConfigManager(prefix=prefix)


# --- Avoid ---
# def bad_indent():
#   return 1          # wrong: 2 spaces instead of 4
#
# class bad:pass      # wrong: no blank lines, no PascalCase
