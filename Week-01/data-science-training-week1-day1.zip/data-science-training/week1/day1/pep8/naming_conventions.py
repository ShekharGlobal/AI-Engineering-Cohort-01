"""PEP-8 Naming Conventions — Week 1, Day 1.

Covers: snake_case, PascalCase, UPPER_SNAKE_CASE, private prefix.
"""

# --- Variables: snake_case ---
user_name = "alice"
max_retries = 3
is_connected = False

# --- Constants: UPPER_SNAKE_CASE ---
DEFAULT_TIMEOUT = 30
BASE_URL = "https://api.platform.internal"
MAX_BATCH_SIZE = 512


# --- Functions: snake_case ---
def load_records(file_path):
    pass


def _validate_schema(data):  # _leading = private/internal
    pass


# --- Classes: PascalCase ---
class DataLoader:
    pass


class ConfigManager:
    pass


class PipelineRunner:
    pass


# --- Avoid: these all fail PEP-8 ---
# UserName = "alice"        # wrong: PascalCase for a variable
# LOADRECORDS = lambda: {}  # wrong: all-caps function
# dataloader = object()     # wrong: no separation in class name
