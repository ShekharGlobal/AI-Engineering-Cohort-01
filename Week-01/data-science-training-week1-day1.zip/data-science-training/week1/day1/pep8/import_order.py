"""PEP-8 Import Ordering — Week 1, Day 1.

Rule: stdlib → third-party → local, each block separated by a blank line.
isort automates this ordering on every save.
"""

# Block 1: Python standard library
import logging
import os
from pathlib import Path
from typing import Optional

# Block 2: Third-party packages (installed via pip)
import pandas as pd
import sqlalchemy
from azure.identity import DefaultAzureCredential
from pydantic import BaseModel

# Block 3: Local / project-internal imports
# from platform_sdk.config import ConfigManager
# from platform_sdk.logging import get_logger


# --- Avoid: mixed blocks, no blank lines ---
# import pandas as pd
# import os
# from platform_sdk.config import ConfigManager   # wrong: all mixed together
# import logging
