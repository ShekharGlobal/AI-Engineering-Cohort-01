"""Complete working example — all Day 1 concepts applied together.

This file demonstrates PEP-8, modern type hints, and Google-style
docstrings working together in a realistic platform function.

Source: solution.py (Week 1, Day 1 practice)
"""


def calculate_tax_inclusive_price(
    raw_data: list[dict[str, float]],
    tax_rate: float = 0.18,
) -> list[float]:
    """Calculate the final price including tax for a list of product records.

    Iterates over a list of product dicts, reads the 'price' key from
    each, applies the tax rate, and returns a list of rounded prices.

    Args:
        raw_data (list[dict[str, float]]): List of product records.
            Each dict must contain a 'price' key (float). Missing keys
            default to 0.0.
        tax_rate (float): Decimal tax rate to apply. Defaults to 0.18
            (18% GST).

    Returns:
        list[float]: Tax-inclusive prices rounded to 2 decimal places,
            one entry per input record.

    Example:
        >>> records = [{"price": 100.0}, {"price": 250.50}]
        >>> calculate_tax_inclusive_price(records)
        [118.0, 295.59]
    """
    processed_prices: list[float] = []

    for record in raw_data:
        price: float = record.get("price", 0.0)
        final_price: float = round(price * (1 + tax_rate), 2)
        processed_prices.append(final_price)

    return processed_prices


if __name__ == "__main__":
    sample_payload: list[dict[str, float]] = [
        {"price": 100.0, "item": "Server Alpha"},
        {"price": 250.50, "item": "Storage Beta"},
    ]

    results = calculate_tax_inclusive_price(sample_payload)
    print(f"Processed Corporate Prices: {results}")
    # Output: Processed Corporate Prices: [118.0, 295.59]
