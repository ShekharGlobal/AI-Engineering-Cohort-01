"""Docstrings — Google Style — Week 1, Day 1.

Three docstring forms:
  1. One-liner   — simple functions, one sentence, period at end
  2. Full        — Args / Returns / Raises / Example sections
  3. Class       — class purpose + Attributes section
"""

from pathlib import Path
from typing import Optional
import json


# ---------------------------------------------------------
# 1. One-liner docstring
# ---------------------------------------------------------

def is_healthy(status_code: int) -> bool:
    """Return True if the HTTP status code indicates success."""
    return 200 <= status_code < 300


def slugify(text: str) -> str:
    """Convert text to a URL-safe lowercase slug."""
    return text.lower().replace(" ", "-")


def chunk(lst: list, size: int) -> list[list]:
    """Split a list into fixed-size chunks."""
    return [lst[i:i + size] for i in range(0, len(lst), size)]


# ---------------------------------------------------------
# 2. Full Google-style docstring
# ---------------------------------------------------------

def load_config(
    path: str,
    env: Optional[str] = None,
    strict: bool = False,
) -> dict:
    """Load a JSON config file and optionally filter by environment.

    Reads the file at the given path, parses it as JSON, and returns
    the config dict. If env is provided, returns only the sub-dict
    for that environment key.

    Args:
        path (str): Absolute or relative path to the JSON config file.
        env (str, optional): Environment key to select (e.g. 'staging').
            If None, returns the full config. Defaults to None.
        strict (bool): If True, raises KeyError when env key is absent.
            Defaults to False.

    Returns:
        dict: The parsed configuration dictionary.

    Raises:
        FileNotFoundError: If the file at path does not exist.
        json.JSONDecodeError: If the file contents are not valid JSON.
        KeyError: If strict=True and the env key is not in the config.

    Example:
        >>> cfg = load_config("config.json", env="production")
        >>> cfg["db_host"]
        'prod.db.internal'
    """
    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config not found: {path}")

    with open(config_path) as f:
        data = json.load(f)

    if env is None:
        return data

    if strict and env not in data:
        raise KeyError(f"Environment key '{env}' not in config.")

    return data.get(env, {})


# ---------------------------------------------------------
# 3. Class docstring with Attributes section
# ---------------------------------------------------------

class DataLoader:
    """Loads and validates batches of records from a data source.

    Provides a consistent interface for reading structured records,
    applying schema validation, and yielding fixed-size batches
    suitable for downstream pipeline stages.

    Attributes:
        source (str): URI or path to the data source.
        batch_size (int): Number of records per yielded batch.
        validated (int): Count of successfully validated records so far.

    Example:
        >>> loader = DataLoader(source="data/records.jsonl")
        >>> for batch in loader.stream():
        ...     process(batch)
    """

    def __init__(self, source: str, batch_size: int = 64) -> None:
        """Initialise the loader.

        Args:
            source (str): URI or file path to read records from.
            batch_size (int): Records per batch. Defaults to 64.
        """
        self.source = source
        self.batch_size = batch_size
        self.validated = 0

    def stream(self):
        """Yield batches of validated records from the source.

        Yields:
            list[dict]: A batch of validated record dictionaries.

        Raises:
            ConnectionError: If the source is unreachable.
            ValueError: If a record fails schema validation.
        """
        pass  # implementation added in Day 2 OOP session
