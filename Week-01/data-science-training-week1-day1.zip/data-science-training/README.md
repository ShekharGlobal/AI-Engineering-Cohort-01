# data-science-training

Personal training repository — 8-week data science program.
1 hour/day · 5 days/week · conceptual + code practice.

---

## Structure

```
data-science-training/
└── week1/
    └── day1/                    ← Python engineering standards
        ├── pep8/
        │   ├── naming_conventions.py   # snake_case, PascalCase, UPPER_SNAKE
        │   ├── indentation.py          # 4-space indent, blank lines, line length
        │   └── import_order.py         # stdlib → third-party → local
        ├── type_hints/
        │   ├── optional_union.py       # Optional, Union, X | Y
        │   ├── collection.py           # list, dict, tuple, set, Callable
        │   └── structured_type.py      # TypedDict, @dataclass
        ├── docstrings/
        │   ├── google.py               # one-liner, full, class docstrings
        │   └── solution.py             # complete working example (all concepts)
        ├── tests/
        │   └── test.py                 # pytest tests for solution + type hints
        └── pyproject.toml              # black, isort, mypy, pytest config
```

---

## Setup

```bash
# 1. Clone the repo
git clone https://github.com/<your-username>/data-science-training.git
cd data-science-training

# 2. Create virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Install dev tools
pip install -e ".[dev]"          # run from week1/day1/
```

---

## Running the tools

```bash
cd week1/day1

# Auto-format
black .

# Sort imports
isort .

# Lint (style violations)
flake8 .

# Type check
mypy docstrings/solution.py

# Run all tools in one line
black . && isort . && flake8 . && mypy docstrings/solution.py

# Run tests
pytest tests/test.py -v
```

---

## Week 1 progress

| Day | Topic | Files | Status |
|-----|-------|-------|--------|
| Day 1 | PEP-8, type hints, docstrings, toolchain | pep8/, type_hints/, docstrings/ | ✅ |
| Day 2 | OOP — classes, inheritance | oop/ | ⬜ |
| Day 3 | OOP — abstract classes, DI | oop/ | ⬜ |
| Day 4 | Async & CLI automation | async_cli/ | ⬜ |
| Day 5 | Behavioral: written communication | — | ⬜ |
